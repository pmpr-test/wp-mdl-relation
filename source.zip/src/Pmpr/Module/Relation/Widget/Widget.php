<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec2680ee5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Widget; use Pmpr\Module\Relation\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Post::ksyueceqagwomguk(); } }
