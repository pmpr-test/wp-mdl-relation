<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92477dea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Widget; use Pmpr\Module\Relation\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Post::ksyueceqagwomguk(); } }
