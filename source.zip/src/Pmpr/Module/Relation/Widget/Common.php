<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705178fdd26e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
