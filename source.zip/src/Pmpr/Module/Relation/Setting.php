<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705321cb90b8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function wyyuauosmqoeucmg() { $this->title = __("\x52\145\x6c\141\x74\x69\x6f\x6e", PR__MDL__RELATION); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\122\145\154\x61\164\x69\x6f\x6e\x20\123\x65\164\164\151\x6e\147", PR__MDL__RELATION)); } }
