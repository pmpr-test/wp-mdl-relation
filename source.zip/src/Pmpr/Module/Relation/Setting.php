<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7b954abb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x52\145\154\141\164\x69\157\156", PR__MDL__RELATION); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\122\x65\154\x61\164\x69\x6f\156\40\x53\145\164\x74\x69\156\x67", PR__MDL__RELATION)); } }
