<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b74ba1149             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function wyyuauosmqoeucmg() { $this->title = __("\122\x65\x6c\x61\x74\151\157\156", PR__MDL__RELATION); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\122\145\x6c\x61\164\x69\x6f\x6e\x20\123\145\164\164\x69\156\147", PR__MDL__RELATION)); } }
