<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc57b482d1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function wyyuauosmqoeucmg() { $this->title = __("\x52\145\x6c\141\164\151\157\156", PR__MDL__RELATION); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x52\x65\x6c\141\164\x69\x6f\156\40\123\x65\164\164\151\x6e\x67", PR__MDL__RELATION)); } }
