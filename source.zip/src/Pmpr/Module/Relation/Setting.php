<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681fcebf29af3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->gswweykyogmsyawy(__('Relation', PR__MDL__RELATION))->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __('Relation Setting', PR__MDL__RELATION)); parent::qiccuiwooiquycsg(); } }
