<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec2680ee5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { public function ckgmycmaukqgkosk() { $quowyokcwswmuois = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm($quowyokcwswmuois)->myysgyqcumekoueo(); parent::ckgmycmaukqgkosk(); } }
