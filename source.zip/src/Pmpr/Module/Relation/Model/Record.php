<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7b954abb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Record extends Common { const kuuiowmkimmuywsm = "\162\145\154\141\x74\151\157\x6e\x5f\x49\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::emuwacasoaaageiq)->guiaswksukmgageq(__("\122\x65\143\x6f\x72\x64", PR__MDL__RELATION))->muuwuqssqkaieqge(__("\122\x65\x63\157\x72\x64\163", PR__MDL__RELATION)); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(Constants::igecewwoemccgwsq)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\117\162\x69\147\x69\156", PR__MDL__RATING)))->cquokmemekqqywgi($this->qoemykoeuecmsmwe(Constants::gygsikewooaciecc)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\x44\x65\x73\164\151\156\141\164\151\x6f\156", PR__MDL__RATING)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::kuuiowmkimmuywsm)->uwmyqckcyamwaiww(Relation::class)->wuuqgaekqeymecag()->gswweykyogmsyawy(__("\x52\145\x6c\141\x74\x69\x6f\x6e", PR__MDL__RATING))); parent::ewaqwooqoqmcoomi(); } }
