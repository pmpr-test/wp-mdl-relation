<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0a60040d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; use Pmpr\Module\Relation\Container; class Backend extends Container { }
