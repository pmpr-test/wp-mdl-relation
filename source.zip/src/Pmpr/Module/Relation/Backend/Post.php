<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705da5a0422             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; use Pmpr\Module\Relation\Container; class Post extends Container { }
