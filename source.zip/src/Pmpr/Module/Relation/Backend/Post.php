<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9810e0814             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; use Pmpr\Module\Relation\Container; class Post extends Container { }
