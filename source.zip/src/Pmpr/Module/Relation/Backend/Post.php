<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681fcf2554cf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; use Pmpr\Module\Relation\Container; class Post extends Container { }
